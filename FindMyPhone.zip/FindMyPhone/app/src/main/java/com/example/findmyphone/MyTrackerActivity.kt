package com.example.findmyphone

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.view.*
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_my_tracker.*
import kotlinx.android.synthetic.main.contact_ticket.view.*
import java.util.ArrayList

class MyTrackerActivity : AppCompatActivity() {
    var adapter:ContactAdapter?=null
    private var listOfContact=ArrayList<UserContact>()
    var userData:UserData?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_tracker)
        userData= UserData(applicationContext)
       // dummyData()
        adapter= ContactAdapter(this,listOfContact)
        lvContactList.adapter=adapter
        lvContactList.onItemClickListener=AdapterView.OnItemClickListener{
                parent, view, position, id ->
            val userInfo=listOfContact[position]
            UserData.myTrackers.remove(userInfo.phoneNumber)
            refreshData()

            //save to shared preferences
            userData!!.saveContactInfo()

            //remove from firebase
            val mDatabase = FirebaseDatabase.getInstance().reference
            val userData=UserData(applicationContext)
            mDatabase.child("Users").child(userInfo.phoneNumber!!).child("Finders").child(
                userData.loadPhoneNumber()
            ).removeValue()


        }
        userData!!.loadContactInfo()
        refreshData()
    }
    //for first time debugging
    fun dummyData(){
       // listOfContact.add(UserContact("Amal","4377777"))
        //listOfContact.add(UserContact("Amall","4376677"))
        //listOfContact.add(UserContact("Amalj","4378877"))

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater=menuInflater
        inflater.inflate(R.menu.tracker_menu,menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item!!.itemId){
            R.id.finishActivity->{
                finish()

            }
            R.id.addContact->{
                 checkPermission()
            }
            else->{
                return super.onOptionsItemSelected(item)
            }

        }
        return true
    }
    val CONTACT_CODE=123
    fun checkPermission(){
        if (Build.VERSION.SDK_INT>=23){
            if (ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_CONTACTS)!=
                PackageManager.PERMISSION_GRANTED){
                requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS),CONTACT_CODE)
                return
            }

        }
        pickcontact()

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when(requestCode){
            CONTACT_CODE->{
                if (grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    pickcontact()
                }else{
                    Toast.makeText(this,"cannot access to contact",Toast.LENGTH_LONG).show()
                }
            }
            else->{
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }

    }
    val PICK_CODE=1234
    fun pickcontact(){
        //here we r opening the contact app
        val intent=Intent(Intent.ACTION_PICK,ContactsContract.Contacts.CONTENT_URI)
        startActivityForResult(intent,PICK_CODE)

    }
    //taking result from the above activity
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when(requestCode){
            PICK_CODE->{
                if (resultCode==AppCompatActivity.RESULT_OK){
                    val contactData=data!!.data
                    val c= contentResolver.query(contactData!!,null,null,null,null)

                    if (c!!.moveToFirst()){

                        val contactData=data!!.data
                        val c= contentResolver.query(contactData!!,null,null,null,null)

                        if (c!!.moveToFirst()){

                            val id= c!!.getString(c!!.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
                            val hasPhone= c!!.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.HAS_PHONE_NUMBER))

                            if (hasPhone.equals("1")){
                                val phones= contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null
                                    , ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=" + id, null,null)

                                phones!!.moveToFirst()
                                var phoneNumber = phones!!.getString(phones!!.getColumnIndex("data1"))
                                val name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))

                                phoneNumber=UserData.formatPhoneNumber(phoneNumber)
                                UserData.myTrackers.put(phoneNumber,name)
                                refreshData()
                                //save to shared ref
                                userData!!.saveContactInfo()

                                // save to Realtime database
                                val mDatabase = FirebaseDatabase.getInstance().reference
                                val userData= UserData(applicationContext)
                                mDatabase.child("Users").child(phoneNumber).child("Finders").child(userData.loadPhoneNumber()).setValue(true)

                            }

                        }

                    }
                }

            }
            else->{
                super.onActivityResult(requestCode, resultCode, data)
            }
        }

    }
    fun refreshData(){
        listOfContact.clear()
        for ((key,value) in UserData.myTrackers){
            listOfContact.add(UserContact(value, key))
        }
        adapter!!.notifyDataSetChanged()

    }

    class ContactAdapter:BaseAdapter{
        var listOfContact=ArrayList<UserContact>()
        var context:Context?=null

        constructor(context:Context,listOfContact:ArrayList<UserContact>){
            this.context=context
            this.listOfContact=listOfContact
        }
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val userContact=listOfContact[position]
            val inflater = context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val contactTicketView=inflater.inflate(R.layout.contact_ticket,null)
            contactTicketView.tvName.text=userContact.name
            contactTicketView.tvPhoneNumber.text=userContact.phoneNumber
            return contactTicketView
        }

        override fun getItem(position: Int): Any {
            return listOfContact[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
           return listOfContact.size
        }

    }
}