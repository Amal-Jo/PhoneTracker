package com.example.findmyphone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_login.*
import java.text.SimpleDateFormat
import java.util.*

class LoginActivity : AppCompatActivity() {

    var mAuth:FirebaseAuth?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val userPhone=findViewById(R.id.etPhoneNumber) as EditText
        val registerButton=findViewById(R.id.buttonReg)as Button

        registerButton.setOnClickListener {
            val userData=UserData(this)
            userData.savePhoneData(userPhone.text.toString())

            //get datatime
            val df =SimpleDateFormat("yyyy/MMM/dd HH:MM:ss")
            val date=Date()

            //save to database
            val mDatabase =FirebaseDatabase.getInstance().reference
            mDatabase.child("Users").child(userPhone.text.toString()).child("request").setValue(df.format(date).toString())
            Log.i("data","success")
            mDatabase.child("Users").child(userPhone.text.toString()).child("Finders").setValue(df.format(date).toString())
            finish()
        }
        mAuth=FirebaseAuth.getInstance()
        signInAnonymously()
    }
    fun signInAnonymously(){
        mAuth!!.signInAnonymously()
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Toast.makeText(applicationContext, "Authentication success.",
                        Toast.LENGTH_SHORT).show()
                    val user = mAuth!!.getCurrentUser()

                } else {
                    Toast.makeText(applicationContext, "Authentication failed.",
                        Toast.LENGTH_SHORT).show()

                }
            }

    }
}